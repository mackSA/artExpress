<?php if(count($errors)> 0): ?>
<div class="alert alert-danger alert-dismissible">
    <?php foreach($errors->all() as $error): ?>
    <ul>
        <li><p><?php echo e($error); ?></p></li> 
    </ul>
    <?php endforeach; ?>
</div>    
<?php endif; ?>    
<?php if(Session::has('succes_message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">   
    <h5><?php echo e(Session::get('succes_message')); ?></h5>
</div>
<?php endif; ?>