<!DOCTYPE html>
<html>
    <head>
  <meta charset="UTF-8">
  <meta name="description" content="Art gallery">
  <meta name="keywords" content="Art,gallary">
  <meta name="author" content="mack morerwa">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">  
        <title>ArtExpress</title>
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?php echo e(URL::to('css/materialize.min.css')); ?>"  media="screen,projection"/> 
      <link type="text/css" rel="stylesheet" href="<?php echo e(URL::to('css/css.css')); ?>"  media="screen,projection"/> 
    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="<?php echo e(URL::to('js/materialize.min.js')); ?>"></script>  
       <script>
             $(".button-collapse").sideNav();
          //$('.collapsible').collapsible();
      </script>
    </body>
</html>
