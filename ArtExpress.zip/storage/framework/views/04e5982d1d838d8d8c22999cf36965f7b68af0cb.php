<?php $__env->startSection('content'); ?>
<nav>
    <div class="nav-wrapper">
        <a href="#" class="brand-logo center" style="font-family: 'Dancing Script', cursive;">ART EXPRESS</a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="sass.html">Sass</a></li>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">JavaScript</a></li>
      </ul>
       <ul class="side-nav" id="mobile-demo">
        <li><a href="sass.html">Sass</a></li>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">Javascript</a></li>
        <li><a href="mobile.html">Mobile</a></li>
      </ul>
    </div>
</nav>
<div class="row">
    <div class="col s12 m8 offset-m2 l6 offset-l3 ">
        <div id="header">
            <h1 class="black-text">ART EXPRESS<span><img src="<?php echo e(URL::to('images/art_brush_2.png')); ?>"></span></h1>
        </div>
    </div>
</div> 
 <div id="blocks">    
    <div class="row">
        <div class="col s12  m4 l4 ">
            <div class="card blue-grey darken-1" style="border-radius: 15px 70px;">
            <div class="card-content white-text">
                <span class="card-title" style="text-align: center;"><img src="images/camera.png"></span>
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
          </div>
        </div>
         <div class="col s12  m4 l4 ">
            <div class="card blue-grey darken-1" style="border-radius: 70px 70px;">
            <div class="card-content white-text">
                <span class="card-title" style="text-align: center;"><img src="images/potrait.png"></span>
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
          </div>
        </div>
         <div class="col s12  m4 l4 ">
            <div class="card blue-grey darken-1" style="border-radius: 70px 15px;">
            <div class="card-content white-text">
              <span class="card-title" style="text-align: center;"><img src="images/pencil.png"></span>
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
          </div>
        </div>
    </div>      
</div>
<footer class="page-footer" style="margin-top: 70px;">
    <div class="footer-copyright">
        <div class="container">
            © 2014 Copyright Text
        </div>
    </div>
</footer>         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>