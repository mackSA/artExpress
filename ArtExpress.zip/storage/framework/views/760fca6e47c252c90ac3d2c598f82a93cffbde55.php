<?php $__env->startSection('content'); ?>
<div id="head">
    <div class="row">
        <div class="col s10 offset-s1 m4 offset-m2 l2 offset-l4">
            <img class="responsive-img circle" src="uploads/profiles/<?php echo e($user->avator); ?>">
            <?php if($user->id = Auth::user()): ?>
            <a href="#upload_image" class="waves-effect waves-purple btn-flat"style=" margin-left: 55px;">Update picture</a>
            <?php endif; ?>
              <!--edit image modal-->
            <div id="upload_image" class="modal">
                <form action="<?php echo e(route('update_image')); ?>" method="POST" enctype="multipart/form-data" class="col s10" style="padding-bottom: 20px">
                <div class="row">
                  <div class="input-field col s12">
                      <h5 style="font-family: 'Dancing Script', cursive;">Upload image:</h5>
                      <input id="image" name="profile_img"  type="file" class="validate">
                    
                  </div>
                </div>
                <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
        
                    <a href="#!" class="left modal-action modal-close waves-effect waves-red btn-flat" style="border: 1px red solid;margin:20px;">Cancel</a>
                    
                    <button type="submit" name="update" class=" waves-effect waves-green btn-flat" style="border: 1px green solid;margin:20px;">Save</button>
                
                 </form>  
            </div>
            <!--end of modal-->
        </div>
        <div class="col s10 offset-s2 m6 l5" style="margin-top: 20px;">
             
            <h3 style="font-family: 'Dancing Script', cursive;"><?php echo e($user->username); ?></h3>
           
   
             <?php if($user->id = Auth::user()): ?>
            <a href="#Edit_profile" class="waves-effect waves-purple btn-flat"style="border:1px solid black">Edit Profile</a>
            <?php endif; ?>
          
              <!--edit profile modal-->
            <div id="Edit_profile" class="modal">
                <form action="<?php echo e(route('update')); ?>" method="POST" class="col s10" style="padding-bottom: 20px">
                    <div class="row">
                      <div class="input-field col s12">
                          <input id="email" name="email"  type="email" class="validate">
                        <label for="email">Email</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <input id="username" name="username" type="text" class="validate">
                        <label for="username">Username</label>
                      </div>
                    </div>          
                     <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">

                        <a href="#!" class="left modal-action modal-close waves-effect waves-red btn-flat" style="border: 1px red solid;margin: 20px;">Cancel</a>

                        <button type="submit" name="update" class=" waves-effect waves-green btn-flat" style="border: 1px green solid;margin: 20px;">Save</button>
                </form>  
            </div>
            <!--end of modal-->
            <h5 style="font-family: 'Dancing Script', cursive;"><?php echo e($user->fullname); ?></h5>
        </div>
    </div>
    <div class="row"style="text-align: center">
    <div class="col s12 m10 offset-m1 l10 offset-l1">    
        <nav>
            <div class="nav-wrapper light-green lighten-3">
                <ul id="nav-mobile" class="col s12">
                    <li><a href="<?php echo e(URL::route('Home_view')); ?>" class="waves-effect waves-purple btn-flat"style="border:1px solid black;"><i class="Medium material-icons">assignment_ind</i> </a></li>
                <li><a  href="<?php echo e(URL::route('Explore_view')); ?>" class="waves-effect waves-purple btn-flat"style="border:1px solid black;"><i class="Medium material-icons">visibility</i></a></li>  
              </ul>
            </div>
        </nav>
    </div>
</div>        
</div>
<div class="row">
    <div class="col s12 m10 offset-m1 l10 offset-l1">
        <?php echo $__env->make('includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <a href="#Post" class="waves-effect waves-purple btn-flat"style="border:1px solid black;"><p style="font-family: 'Dancing Script', cursive;">Post image</p></a>
            <!--edit profile modal-->
           <div id="Post" class="modal">
               <form action="<?php echo e(route('upload_post')); ?>" method="POST"  enctype="multipart/form-data" class="col s10" style="padding-bottom: 20px">
                <div class="row"
                    <div class="input-field col s12">
                      <h5 style="font-family: 'Dancing Script', cursive;">Upload image:</h5>
                      <input id="image" name="upload"  type="file" class="validate">
                    </div>
                      <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
                    <a href="#!" class="left modal-action modal-close waves-effect waves-red btn-flat" style="border: 1px red solid;margin: 10px;">Cancel</a>
            
                    <button type="submit" name="update" class=" waves-effect waves-green btn-flat" style="border: 1px green solid;margin:10px;">Save</button>    
                 </form>  
            </div>
            <!--end of modal-->
        
        <a href="<?php echo e(URL::route('Logout')); ?>" class="waves-effect right waves-purple btn-flat"style="border:1px solid black;"><p style="font-family: 'Dancing Script', cursive;">Logout</p></a>
        
    </div>
</div>
<div class="container-fluid"> 
    <div class="row">
    <?php foreach($post as $post): ?>
        <div class="col s12 m4 l3">
            <div class="card">
                <div class="card-image">
                    <img src="/uploads/uploads/<?php echo e($post->post); ?>">
                    <?php if($user->id = $post->user_id): ?>
                    <a class="btn-floating halfway-fab waves-effect waves-light-green-lighten-3"><i class="material-icons">delete</i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>